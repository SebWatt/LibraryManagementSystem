﻿namespace LibraryManagementSystem.Models
{
    public class Constants
    {
        public const string SuperAdminRole = "superAdmin";
        public const string AdminRole = "admin";
        public const string LibrarianRole = "librarian";
        public const string BorrowerRole = "borrower";

    }
}
